/**
 * make a selected mode and every time you click on one item it getts selected
 * make a trash can appear in the corner
 * when you long click while already in select mode views can be dragged around!
 * look into existing gridview select functionality
 * possibly in the same way gmail list view are selected with the pic flipped around
 *
 * https://github.com/Comcast/FreeFlow
 */



package saboor.testexlist;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.PointF;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.Parse;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import uk.co.senab.actionbarpulltorefresh.library.ActionBarPullToRefresh;
import uk.co.senab.actionbarpulltorefresh.library.Options;
import uk.co.senab.actionbarpulltorefresh.library.PullToRefreshLayout;
import uk.co.senab.actionbarpulltorefresh.library.listeners.OnRefreshListener;

public class
        main extends Activity {
    ExpandableListAdapter listAdapter;
    ExpandableListView expListView;
    List<String> listDataHeader;
    List<channel> mChannels;
    HashMap<String, List<channel>> listDataChild;
    private int mPhotoSize, mPhotoSpacing;
    ParseDBCommunicator parseDBCommunicator;
    movableGridAdapter MGA;
    DynamicGridView gridView;
    private int draggedIndex = -1;
    ImageView trash_icon;
    RelativeLayout lr;
    RelativeLayout trash_view;
    PointF start = new PointF();
    PointF mid = new PointF();
    TextView rh;
    int width;
    database_handler db;

    SwipeRefreshLayout swipeLayout;
    private PullToRefreshLayout mPullToRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        this.overridePendingTransition(R.anim.in_from_left,
                R.anim.out_to_right);


        Parse.initialize(this, "4WShWGs2N5eF0WL3qBj3Gbqm61JyY3tPzSzVU6Q0", "TLe2dAXt8RUiYA1IwUmnm2He2DO0j12qq7bx02lu");

        //requestWindowFeature(Window.FEATURE_NO_TITLE);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
        //WindowManager.LayoutParams.FLAG_FULLSCREEN);



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new database_handler(getApplicationContext());

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        width = size.x;
        int height = size.y;


        mPullToRefreshLayout = (PullToRefreshLayout) findViewById(R.id.ptr_layout);


        // Now setup the PullToRefreshLayout
        ActionBarPullToRefresh.from(this)

                // Mark All Children as pullable
                .allChildrenArePullable()
                        // Set a OnRefreshListener
                .listener(new OnRefreshListener() {
                    @Override
                    public void onRefreshStarted(View view) {
                        new Handler().postDelayed(new Runnable() {
                            @Override public void run() {

                                Thread client = new Thread(new Runnable() {
                                    public void run() {
                                        mChannels = db.getAllLocalChannels();
                                        if(MGA.isDataSetNew(mChannels))
                                        {
                                            showToast("Refreshed");
                                            MGA.set(mChannels);
                                        }else {
                                            showToast("No new items!");
                                        }
                                    }
                                });
                                client.start();
                                //wait for background thread to finish
                                try {
                                    client.join();
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                MGA.set(mChannels);
                                mPullToRefreshLayout.setRefreshComplete();
                            }
                        }, 2000);

                    }
                }).options(Options.create().refreshOnUp(true).build())
        // Finally commit the setup to our PullToRefreshLayout
        .setup(mPullToRefreshLayout);



        final ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);

        gridView = (DynamicGridView) findViewById(R.id.dynamic_grid);

        mChannels = new ArrayList<channel>();
        parseDBCommunicator = new ParseDBCommunicator(getApplicationContext());
        Thread client = new Thread(new Runnable() {
            public void run() {
               //mChannels = parseDBCommunicator.getChannelsWithVideos();
                //for(int i = 0; i < mChannels.size(); i++)
                //{
                //    db.addChannel(mChannels.get(i).getChannel_id());
               // }
                mChannels = db.getAllLocalChannels();
            }
        });
        client.start();
        //wait for background thread to finish
        try {
            client.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        //db.printDB();
        Log.d("Size of list", "Size of list: " + mChannels.size());

        MGA = new movableGridAdapter(mChannels , getApplicationContext(), 3, width/3 - (gridView.getHorizontalSpacing()*4));


        gridView.setAdapter(MGA);

        progressBar.setVisibility(View.GONE);
        gridView.setVisibility(View.VISIBLE);

        gridView.setWobbleInEditMode(true);
        gridView.setHapticFeedbackEnabled(true);


        trash_view = (RelativeLayout) findViewById(R.id.trash);
        trash_icon = (ImageView) findViewById(R.id.trash_icon);


        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                gridView.startEditMode();
                gridView.deleteModeOn();//********************************************************^&(*&
                MGA.setDeleteMode(true);
                return false;
            }

        });

        gridView.setOnDragListener(new DynamicGridView.OnDragListener() {
            @Override
            public void onDragStarted(int position) {
                //Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.alpha_in);
                //trash_view.setVisibility(View.VISIBLE);
                //trash_view.startAnimation(anim);
                draggedIndex = position;
            }

            @Override
            public void onDragPositionsChanged(int oldPosition, int newPosition) {

            }
        });

        gridView.setOnDropListener(new DynamicGridView.OnDropListener() {
            @Override
            public void onActionDrop() {
                // stop edit mode immediately after drop item
                Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.alpha_out);
                gridView.stopEditMode();
                db.saveOrder(MGA.getChannels());
            }
        });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), inside_channel.class);

                Field a = null;
                try {
                    a = MGA.getItem(i).getClass().getField("channel_id");
                } catch (NoSuchFieldException e) {
                    e.printStackTrace();
                }
                String id = "error";

                try {
                    id = (String) a.get(MGA.getItem(i));
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }

                Field b = null;
                try {
                    b = MGA.getItem(i).getClass().getField("channel_name");
                } catch (NoSuchFieldException e) {
                    e.printStackTrace();
                }
                String name = "error";

                try {
                    name = (String) b.get(MGA.getItem(i));
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }



                intent.putExtra("channel_id", id);
                intent.putExtra("channel_name", name);
                startActivity(intent);
            }
        });

        // Capture ListView item click

/**
        gridView.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {

            @Override
            public void onItemCheckedStateChanged(ActionMode mode,
                                                  int position, long id, boolean checked) {
                // Capture total checked items
                final int checkedCount = gridView.getCheckedItemCount();
                // Set the CAB title according to total checked items
                mode.setTitle(checkedCount + " Selected");
                // Calls toggleSelection method from ListViewAdapter Class
                Log.d("Multi Select", "Position clicked: " + position);
                MGA.toggleSelection(position);
                //gridView.makeGrayScale(position);
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.unfollow:
                        // Calls getSelectedIds method from ListViewAdapter Class
                        SparseBooleanArray selected = MGA
                                .getSelectedIds();
                        // Captures all selected ids with a loop
                        for (int i = (selected.size() - 1); i >= 0; i--) {
                            if (selected.valueAt(i)) {
                                Object selecteditem = MGA
                                        .getItem(selected.keyAt(i));
                                // Remove selected items following the ids
                                MGA.remove(selecteditem);
                            }
                        }
                        // Close CAB
                        mode.finish();
                        return true;
                    default:
                        Log.d("Action mode", "You did nothing!");
                        return false;
                }
            }

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                mode.getMenuInflater().inflate(R.menu.cab_select, menu);
                return true;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                // TODO Auto-generated method stub
                MGA.removeSelection();
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                // TODO Auto-generated method stub
                return false;
            }
        });
**/
    }
        @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.rearrange:
                gridView.setChoiceMode(AbsListView.CHOICE_MODE_NONE);
                //gridView.setBackgroundColor(getResources().getColor(R.color.black));
                //zoom(0.7f,0.7f,new PointF(findViewById(R.id.parent_layout).getHeight()/2,findViewById(R.id.parent_layout).getWidth()/2));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        if (gridView.isEditMode()) {
            gridView.stopEditMode();
        }
        if(gridView.isDeleteMode())
        {
            gridView.deleteModeOff();
            MGA.setDeleteMode(false);
        }

        //else {
        //    super.onBackPressed();
        //}
    }

    public void showToast(final String toast)
    {
        runOnUiThread(new Runnable() {
            public void run()
            {
                Toast.makeText(main.this, toast, Toast.LENGTH_SHORT).show();
            }
        });
    }

}





