package saboor.testexlist;

import android.content.Context;
import android.util.Log;

import com.parse.Parse;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Saboor Salaam on 6/6/2014.
 */
public class ParseDBCommunicator {

    private Context context;
    static DefaultHttpClient httpClient;
    List<ParseObject> objects;




    ParseDBCommunicator(Context c) {
        this.context = c;
        Parse.initialize(context , "4WShWGs2N5eF0WL3qBj3Gbqm61JyY3tPzSzVU6Q0", "TLe2dAXt8RUiYA1IwUmnm2He2DO0j12qq7bx02lu");
    }


    public List<channel> getChannelsWithVideos()
    {
        List<channel> channels = new ArrayList<channel>();
        List<ParseObject> objects = new ArrayList<ParseObject>();
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Channel"); // get all channels that mach that category
        try {
            objects = query.find();
            Log.d("Channel", "Retrieved " + objects.size() + " channels");
            for( int z = 0; z < objects.size(); z++)
            {
                    channels.add(new channel(objects.get(z).getString("channel_name"), objects.get(z).getString("channel_id"), objects.get(z).getString("cover_thumbnail"),objects.get(z).getString("cover_thumbnail2"), objects.get(z).getInt("newVideos") ));
                }

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return channels;
    }


    public channel getChannel(String id)
    {
        List<ParseObject> objects = new ArrayList<ParseObject>();
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Channel");
        query.whereEqualTo("channel_id", id);
        try {
            objects = query.find();
            Log.d("Channel", "Retrieved " + objects.size() + " channels: " + objects.get(0).getString("channel_name"));
           channel ch = new channel();
           ch.setChannel_name(objects.get(0).getString("channel_name"));
           ch.setChannel_id(objects.get(0).getString("channel_id"));
           ch.setVid1thumb(objects.get(0).getString("cover_thumbnail"));
           ch.setVid2thumb(objects.get(0).getString("cover_thumbnail2"));
           ch.setSize(objects.get(0).getInt("newVideos"));
           return ch;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new channel();
    }

    public List<channel> getSelectedChannels(List<String> ids) //********************************
    {
        List<ParseQuery<ParseObject>> queries = new ArrayList<ParseQuery<ParseObject>>();

        for(int i = 0; i < ids.size(); i++ )
        {
            ParseQuery<ParseObject> matchId = ParseQuery.getQuery("Channel");
            matchId.whereEqualTo("channel_id", ids.get(i));
            queries.add(matchId);
        }

        ParseQuery<ParseObject> mainQuery = ParseQuery.or(queries);// OR Each individual query
        List<ParseObject> objects = new ArrayList<ParseObject>();
        List<channel> channels = new ArrayList<channel>();

        try {
            objects = mainQuery.find();
            Log.d("Channel", "Retrieved " + objects.size() + " channels");
            for( int z = 0; z < objects.size(); z++)
            {
                channels.add(new channel(objects.get(z).getString("channel_name"), objects.get(z).getString("channel_id"), objects.get(z).getString("cover_thumbnail"),objects.get(z).getString("cover_thumbnail2"), objects.get(z).getInt("newVideos") ));
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }


        List<channel> orderedChannels = new ArrayList<channel>();

        boolean notDone = true;

        for(int z = 0; z < ids.size(); z++ ) {
            for (int i = 0; i < channels.size() && notDone; i++) {
                //Log.d("Reorderer", "Found Match Between " + ids.get(z) + " and " + channels.get(i).getChannel_name() + ", " + channels.get(i).getChannel_id());
                if (ids.get(z).equals(channels.get(i).getChannel_id())) {
                    Log.d("Reorderer", "Found Match Between " + ids.get(z) + " and " + channels.get(i).getChannel_name() + ", " + channels.get(i).getChannel_id());
                    channel ch = channels.get(i);
                    orderedChannels.add(ch);
                    notDone = false;
                }
            }
            notDone = true;
        }

        return orderedChannels;
    }




    public List<YouTubeVideo> getVideosofAChannel(String channel_id, String channel_title)
    {
        List<YouTubeVideo> videos = new ArrayList<YouTubeVideo>();
        List<ParseObject> objects = new ArrayList<ParseObject>();
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Video"); // get all channels that mach that category
        query.whereEqualTo("channel_id", channel_id);
        try {
            objects = query.find();
            Log.d("Videos", "Retrieved " + objects.size() + " videos");
            for( int z = 0; z < objects.size(); z++)
            {
                videos.add(new YouTubeVideo(objects.get(z).getString("video_id"), objects.get(z).getString("date_published"),objects.get(z).getString("video_title"), objects.get(z).getString("video_description"), objects.get(z).getString("video_thumbnail"),channel_title));
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return videos;
    }


    public List<category> getAllCategories(){

        List<category> categories = new ArrayList<category>();
        List<ParseObject> objects = new ArrayList<ParseObject>();
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Category");//get all categories from database
        try {
            objects = query.find();
            for( int i = 0; i < objects.size(); i++)//loop through each category
            {
                //int size = getAllChannelsOfACategory(objects.get(i).getString("name")).size();
                categories.add(new category(objects.get(i).getString("name"),10)); // add name to list of headers
                Log.d("Category", "Retrieved " + objects.get(i).getString("name"));
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }

        query.cancel();
        return categories;
    }

     public List<channel> getAllChannelsOfACategory(String category)
     {
         List<channel> channels = new ArrayList<channel>();
         List<ParseObject> objects = new ArrayList<ParseObject>();
         ParseQuery<ParseObject> query = ParseQuery.getQuery("Channel"); // get all channels that mach that category
         query.whereEqualTo("category", category);
          try {
                  objects = query.find();
                  Log.d("Channel", "Retrieved " + objects.size() + " channels");
                  for( int z = 0; z < objects.size(); z++)
                  {
                      channels.add(new channel(objects.get(z).getString("channel_name"), objects.get(z).getString("channel_id"),null,null,10));
                  }

          } catch (ParseException e) {
                     e.printStackTrace();
                 }
        return channels;
     }




    public String httpGet(String url)
    {
        String jsonString = "Error bad url";
        HttpGet httpGet = new HttpGet(url);
        HttpResponse httpResponse = null;
        try {

            httpResponse = httpClient.execute(httpGet);
            HttpEntity httpEntity = httpResponse.getEntity();
            jsonString = EntityUtils.toString(httpEntity);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return jsonString;
    }


    public String getChannelID(String jsonString) {

        JSONObject json = null;
        try {
            json = new JSONObject(jsonString);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String id = "";

        JSONArray jsonArray = null;
        try {
            jsonArray = json.getJSONArray("items");
            JSONObject videoItem = jsonArray.getJSONObject(0);

            id = videoItem.getString("id");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return  id;
    }
}
