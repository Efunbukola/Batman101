package com.explandable_listview.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Saboor Salaam on 6/17/2014.
 */

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 4;

    // Database Name
    private static final String DATABASE_NAME = "app_database";

    private static final String CHANNEL_NAME = "channel_name";

    private static final String CHANNEL_ID = "channel_id";

    private static final String TABLE_CHANNELS = "Channels";


    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CHANNELS_TABLE = "CREATE TABLE channels(" +
                "channel_name text, " +
                "last_updated text, " +
                "channel_id text primary key)";
        db.execSQL(CREATE_CHANNELS_TABLE);

    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS channels");
        // Create tables again
        onCreate(db);
    }

    public void followChannel(YouTubeChannel channel) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(CHANNEL_NAME, channel.getName()); // Contact Name
        values.put(CHANNEL_ID, channel.getId()); // Contact Phone

        // Inserting Row
        db.insert(TABLE_CHANNELS, null, values);
        db.close(); // Closing database connection
    }

    public void unfollowChannel(String channel_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CHANNELS, CHANNEL_ID + " = ?",
                new String[]{channel_id});
        db.close();
    }

    public List<YouTubeChannel> getUsersChannels() {
        List<YouTubeChannel> channelList = new ArrayList<YouTubeChannel>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_CHANNELS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()&& cursor != null) {
            do {
                YouTubeChannel channel = new YouTubeChannel();
                channel.setName(cursor.getString(0));
                channel.setId(cursor.getString(1));
                channelList.add(channel);
            } while (cursor.moveToNext());
        }
        return channelList;
    }


    public void updateChannel(String id) //Has to be called every time list of videos is gotten from a channel
    {

        // get current date format  and store it into database every time videos are retrieved from the channel
        SQLiteDatabase db = this.getWritableDatabase();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-ddHH:mm:ss");

        String dateinfo = dateinfo.substring(0,10) +""+ dateinfo.substring(11,19);
        //2014-06-02T21:58:18.000Z

        //parse date string to get Data object
        try {
            datez = df.parse(dateinfo);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        ContentValues values = new ContentValues();
        values.put("last_updated", channel.getId()); // Contact Phone
        db.update()

    }


    public doesChannelHaveNewVideos(String channel_id)
    {
        //get all videos that are after the last updated date
    }
}




